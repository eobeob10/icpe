import time
import os
import pandas as pd
from contextlib import contextmanager
from catboost import CatBoostClassifier
from sklearn.metrics import average_precision_score
from data_loader import load_raw_data, aggregate_alerts
from preprocessing import perform_time_split, enrich_and_weight_data, engineer_complex_features
from model_utils import prepare_matrix_with_pca, make_pool, calculate_pr_at_k

OUTPUT_DIR = "benchmark_results_static_only"
os.makedirs(OUTPUT_DIR, exist_ok=True)

BEST_PARAMS = {
    "iterations": 2000,
    "eval_metric": "AUC",
    "early_stopping_rounds": 100,
    "verbose": 100,
    "task_type": "CPU",
    "thread_count": 4
}


class BenchmarkPipeline:
    def __init__(self):
        self.data = {}
        self.model = None

    @contextmanager
    def log_step(self, name):
        print(f"\n[Step] {name}...");
        t0 = time.time();
        yield
        print(f"   Done in {time.time() - t0:.2f}s")

    def run(self):
        print("🚀 Benchmark [STATIC ONLY] Started...")
        with self.log_step("1. Loading"): self._step_1_loading()
        with self.log_step("2. Time Series Skipped"): pass
        with self.log_step("3. NLP Skipped"): pass
        with self.log_step("4. Prep"): self._step_4_prep()
        with self.log_step("5. Train"): self._step_5_train()
        with self.log_step("6. Eval"): self._step_6_eval()
        self._step_8_reporting()

    def _step_1_loading(self):
        alerts, bugs = load_raw_data()
        df = aggregate_alerts(alerts)
        df = enrich_and_weight_data(df, bugs)
        df = engineer_complex_features(df)

        # On doit s'assurer que la target est propre (normalement fait dans enrich_with_ts mais on le skip)
        if "bug_created" in df.columns:
            df["bug_created"] = df["bug_created"].fillna(0).astype(int)

        self.data['df'] = df

    def _step_4_prep(self):
        train_val, test = perform_time_split(self.data['df'])
        # Pas d'embeddings passés, pas de TS chargés
        X_train, self.cat_cols, _ = prepare_matrix_with_pca(train_val, embeddings=None, is_train=True)
        X_test, _, _ = prepare_matrix_with_pca(test, embeddings=None, is_train=False)
        self.data['train_val'], self.data['test'] = train_val, test
        self.data['X_train'], self.data['X_test'] = X_train, X_test

        print(f"   Features utilisées (Static): {X_train.shape[1]}")

    def _step_5_train(self):
        X, y = self.data['X_train'], self.data['train_val']['bug_created']
        w = self.data['train_val']['sample_weight']
        split = int(len(X) * 0.90)

        train_pool = make_pool(X.iloc[:split], y.iloc[:split], self.cat_cols, w.iloc[:split])
        val_pool = make_pool(X.iloc[split:], y.iloc[split:], self.cat_cols, w.iloc[split:])

        self.model = CatBoostClassifier(**BEST_PARAMS)
        self.model.fit(train_pool, eval_set=val_pool)

    def _step_6_eval(self):
        test_pool = make_pool(self.data['X_test'], None, self.cat_cols)
        self.probs = self.model.predict_proba(test_pool)[:, 1]
        y_test = self.data['test']['bug_created']
        print(f"   🏆 AUPRC: {average_precision_score(y_test, self.probs):.4f}")
        for k in [50, 100, 200]:
            p, r = calculate_pr_at_k(y_test, self.probs, k)
            print(f"P@{k:<4} | {p:.4f}  R@{k:<4} | {r:.4f}")

    def _step_8_reporting(self):
        fi = self.model.get_feature_importance(type="PredictionValuesChange")
        pd.DataFrame({"feature": self.data['X_test'].columns, "importance": fi}) \
            .sort_values("importance", ascending=False).to_csv(f"{OUTPUT_DIR}/fi.csv")
        print("Feature importance saved.")


if __name__ == "__main__": BenchmarkPipeline().run()